import { Component } from '@angular/core';

@Component({
  selector: 'app-succesfully-register',
  templateUrl: './succesfully-register.component.html',
  styleUrls: ['./succesfully-register.component.css']
})
export class SuccesfullyRegisterComponent {

}
